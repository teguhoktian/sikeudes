## About Siskuedes Web

Aplikasi Siskeudes Web Based adalah aplikasi pengeloala sistem keuangan desa berbasis web. Dikembangkan dengan framework Laravel 8.x.