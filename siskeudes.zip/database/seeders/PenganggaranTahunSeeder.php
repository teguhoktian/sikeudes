<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class PenganggaranTahunSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
