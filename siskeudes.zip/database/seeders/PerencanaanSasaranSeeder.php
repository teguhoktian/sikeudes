<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class PerencanaanSasaranSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
