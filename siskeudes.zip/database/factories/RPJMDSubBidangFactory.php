<?php

namespace Database\Factories;

use App\Models\RPJMDSubBidang;
use Illuminate\Database\Eloquent\Factories\Factory;

class RPJMDSubBidangFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = RPJMDSubBidang::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
