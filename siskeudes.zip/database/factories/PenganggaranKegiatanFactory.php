<?php

namespace Database\Factories;

use App\Models\PenganggaranKegiatan;
use Illuminate\Database\Eloquent\Factories\Factory;

class PenganggaranKegiatanFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = PenganggaranKegiatan::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
