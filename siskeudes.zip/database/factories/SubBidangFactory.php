<?php

namespace Database\Factories;

use App\Models\SubBidang;
use Illuminate\Database\Eloquent\Factories\Factory;

class SubBidangFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = SubBidang::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
