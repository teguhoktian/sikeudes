<?php

namespace Database\Factories;

use App\Models\RekeningObjek;
use Illuminate\Database\Eloquent\Factories\Factory;

class RekeningObjekFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = RekeningObjek::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
