<?php

namespace Database\Factories;

use App\Models\KepalaDesa;
use Illuminate\Database\Eloquent\Factories\Factory;

class KepalaDesaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = KepalaDesa::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
