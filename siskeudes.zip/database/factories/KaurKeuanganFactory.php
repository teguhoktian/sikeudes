<?php

namespace Database\Factories;

use App\Models\KaurKeuangan;
use Illuminate\Database\Eloquent\Factories\Factory;

class KaurKeuanganFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = KaurKeuangan::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
